<?php 
	class Book extends AppModel 
	{ 
		var $validate = array('title' => array('rule' => 'notBlank'));
		var $name = 'Book'; 
	} 
?>